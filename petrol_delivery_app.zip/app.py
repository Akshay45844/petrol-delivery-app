from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key'

orders = []
delivery_people = {
    "ravi": "pass123",
    "sneha": "sneha456"
}
pricing = {
    "petrol": 100,
    "battery": 200
}

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        phone = request.form["phone"]
        address = request.form["address"]
        vehicle = request.form["vehicle"]
        fuel_type = request.form["fuel_type"]
        delivery_person = request.form["delivery_person"]
        payment_method = request.form["payment"]

        price = pricing[fuel_type]
        order = {
            "id": str(uuid.uuid4()),
            "name": name,
            "phone": phone,
            "address": address,
            "vehicle": vehicle,
            "fuel_type": fuel_type,
            "delivery_person": delivery_person,
            "status": "Pending",
            "price": price,
            "payment_method": payment_method,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        orders.append(order)
        return render_template("success.html", order=order)
    return render_template("index.html", pricing=pricing)

@app.route("/delivery", methods=["GET", "POST"])
def delivery():
    if request.method == "POST":
        for order in orders:
            status_key = f"status_{order['id']}"
            if status_key in request.form:
                order["status"] = request.form[status_key]
        for key in pricing:
            if key in request.form:
                pricing[key] = int(request.form[key])
    return render_template("delivery.html", orders=orders, pricing=pricing)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in delivery_people and delivery_people[username] == password:
            session["delivery_person"] = username
            return redirect(url_for("my_deliveries"))
        else:
            return "Invalid login"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("delivery_person", None)
    return redirect(url_for("login"))

@app.route("/mydeliveries")
def my_deliveries():
    if "delivery_person" not in session:
        return redirect(url_for("login"))
    user = session["delivery_person"]
    my_orders = [o for o in orders if o["delivery_person"] == user]
    return render_template("my_deliveries.html", orders=my_orders, user=user)

if __name__ == "__main__":
    app.run(debug=True)